import React, { Component } from 'react';

class Title extends Component {
    render() {
        return (
            <div className="page-header">
                <h1>Project 04 - Spotify <small>ReactJS</small></h1>
            </div>
        );
    }
}

export default Title;
