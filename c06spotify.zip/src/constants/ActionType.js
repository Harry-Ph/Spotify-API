export const GO_HOME 		= 'GO_HOME';
export const GO_ARTIST 		= 'GO_ARTIST';
export const GO_ALBUM 		= 'GO_ALBUM';

export const CHANGE_QUERY 		= 'CHANGE_QUERY';
export const SEARCH_ARTIST 		= 'SEARCH_ARTIST';